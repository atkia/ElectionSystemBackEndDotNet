﻿using System;
using System.Collections.Generic;
using System.Text;
using ServerApp.Model;

namespace ServerApp.Repository
{
    public class DatabaseRepository
    {
        public DatabaseContext DatabaseContext = new DatabaseContext();
    }
}
